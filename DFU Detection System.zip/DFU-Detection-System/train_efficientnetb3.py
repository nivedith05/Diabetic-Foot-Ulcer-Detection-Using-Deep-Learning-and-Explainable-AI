
import os
import json

try:
    import tensorflow as tf
    from tensorflow.keras import layers, models
    from tensorflow.keras.applications import EfficientNetB3
    from tensorflow.keras.callbacks import (
        ModelCheckpoint,
        EarlyStopping,
        ReduceLROnPlateau,
    )

except ImportError as exc:
    raise ImportError(
        "TensorFlow is required to run this training script. "
        "Install it with: pip install tensorflow"
    ) from exc


# ============================================================
# CONFIGURATION
# ============================================================

BASE_DIR = r"C:\Users\nived\Downloads\DFU-Detection-System"

TRAIN_DIR = os.path.join(
    BASE_DIR,
    "dataset",
    "train"
)

VAL_DIR = os.path.join(
    BASE_DIR,
    "dataset",
    "validation"
)

MODEL_DIR = os.path.join(
    BASE_DIR,
    "models"
)

os.makedirs(
    MODEL_DIR,
    exist_ok=True
)

IMG_SIZE = (300, 300)

BATCH_SIZE = 16

EPOCHS = 30

MODEL_PATH = os.path.join(
    MODEL_DIR,
    "efficientnetb3_best.keras"
)


# ============================================================
# GPU / CPU CONFIGURATION
# ============================================================

print("=" * 60)
print("EFFICIENTNETB3 DFU TRAINING")
print("=" * 60)

print("\nTensorFlow version:")
print(tf.__version__)

print("\nChecking GPU...")

gpus = tf.config.list_physical_devices("GPU")

if gpus:
    print("GPU detected:")
    print(gpus)

else:
    print("No GPU detected.")
    print("Training will use CPU.")


# ============================================================
# LOAD DATASETS
# ============================================================

print("\n" + "=" * 60)
print("LOADING DATASET")
print("=" * 60)

print("\nTraining directory:")
print(TRAIN_DIR)

print("\nValidation directory:")
print(VAL_DIR)


train_dataset = tf.keras.utils.image_dataset_from_directory(
    TRAIN_DIR,
    labels="inferred",
    label_mode="binary",
    image_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    shuffle=True,
    seed=42
)


validation_dataset = tf.keras.utils.image_dataset_from_directory(
    VAL_DIR,
    labels="inferred",
    label_mode="binary",
    image_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    shuffle=False
)


print("\nClass mapping:")
print(train_dataset.class_names)

print("\nExpected mapping:")
print("0 = abnormal")
print("1 = normal")


# ============================================================
# PERFORMANCE OPTIMIZATION
# ============================================================

AUTOTUNE = tf.data.AUTOTUNE

train_dataset = train_dataset.prefetch(
    AUTOTUNE
)

validation_dataset = validation_dataset.prefetch(
    AUTOTUNE
)


# ============================================================
# DATA AUGMENTATION
# ============================================================

data_augmentation = tf.keras.Sequential(
    [
        layers.RandomFlip(
            "horizontal"
        ),

        layers.RandomRotation(
            0.08
        ),

        layers.RandomZoom(
            0.10
        ),

        layers.RandomContrast(
            0.10
        ),
    ],
    name="data_augmentation"
)


# ============================================================
# BUILD EFFICIENTNETB3
# ============================================================

print("\n" + "=" * 60)
print("BUILDING EFFICIENTNETB3")
print("=" * 60)

inputs = layers.Input(
    shape=(
        IMG_SIZE[0],
        IMG_SIZE[1],
        3
    ),
    name="input_image"
)


x = data_augmentation(
    inputs
)


# ------------------------------------------------------------
# PRETRAINED EFFICIENTNETB3
# ------------------------------------------------------------

base_model = EfficientNetB3(
    include_top=False,
    weights="imagenet",
    input_shape=(
        IMG_SIZE[0],
        IMG_SIZE[1],
        3
    ),
    name="efficientnetb3"
)


# Freeze pretrained layers initially

base_model.trainable = False


x = base_model(
    x,
    training=False
)


# ------------------------------------------------------------
# CLASSIFICATION HEAD
# ------------------------------------------------------------

x = layers.GlobalAveragePooling2D(
    name="global_average_pooling"
)(x)


x = layers.Dropout(
    0.35,
    name="dropout"
)(x)


outputs = layers.Dense(
    1,
    activation="sigmoid",
    name="prediction"
)(x)


model = models.Model(
    inputs,
    outputs,
    name="DFU_EfficientNetB3"
)


# ============================================================
# MODEL SUMMARY
# ============================================================

print("\nModel created successfully.")

model.summary()


# ============================================================
# COMPILE
# ============================================================

model.compile(
    optimizer=tf.keras.optimizers.Adam(
        learning_rate=1e-4
    ),

    loss="binary_crossentropy",

    metrics=[
        "accuracy",

        tf.keras.metrics.Precision(
            name="precision"
        ),

        tf.keras.metrics.Recall(
            name="recall"
        )
    ]
)


# ============================================================
# CALLBACKS
# ============================================================

checkpoint = ModelCheckpoint(
    MODEL_PATH,
    monitor="val_accuracy",
    mode="max",
    save_best_only=True,
    verbose=1
)


early_stopping = EarlyStopping(
    monitor="val_accuracy",
    mode="max",
    patience=6,
    restore_best_weights=True,
    verbose=1
)


reduce_lr = ReduceLROnPlateau(
    monitor="val_loss",
    factor=0.5,
    patience=2,
    min_lr=1e-7,
    verbose=1
)


# ============================================================
# INITIAL TRAINING
# ============================================================

print("\n" + "=" * 60)
print("STARTING EFFICIENTNETB3 TRAINING")
print("=" * 60)


history = model.fit(
    train_dataset,
    validation_data=validation_dataset,
    epochs=EPOCHS,
    callbacks=[
        checkpoint,
        early_stopping,
        reduce_lr
    ]
)


# ============================================================
# LOAD BEST MODEL
# ============================================================

print("\n" + "=" * 60)
print("LOADING BEST MODEL")
print("=" * 60)

model = tf.keras.models.load_model(
    MODEL_PATH
)

print(
    "Best model loaded from:"
)

print(
    MODEL_PATH
)


# ============================================================
# EVALUATE VALIDATION SET
# ============================================================

print("\n" + "=" * 60)
print("VALIDATION EVALUATION")
print("=" * 60)

results = model.evaluate(
    validation_dataset,
    verbose=1
)


print("\nValidation results:")

for name, value in zip(
    model.metrics_names,
    results
):

    print(
        f"{name}: {value:.4f}"
    )


# ============================================================
# OPTIONAL FINE-TUNING
# ============================================================

print("\n" + "=" * 60)
print("STARTING FINE-TUNING")
print("=" * 60)


# Unfreeze the EfficientNet base

base_model.trainable = True


# Freeze most early layers.
# Fine-tune only the later layers.

fine_tune_from = 300


for layer in base_model.layers:

    if layer.name.startswith("input"):

        layer.trainable = False

    elif layer.name.startswith("rescaling"):

        layer.trainable = False

    else:

        layer.trainable = False


# Unfreeze later layers

for layer in base_model.layers[
    fine_tune_from:
]:

    layer.trainable = True


print(
    "\nTrainable layers:"
)

trainable_count = sum(
    layer.trainable
    for layer in base_model.layers
)

print(
    trainable_count
)


# ============================================================
# RECOMPILE FOR FINE-TUNING
# ============================================================

model.compile(
    optimizer=tf.keras.optimizers.Adam(
        learning_rate=1e-5
    ),

    loss="binary_crossentropy",

    metrics=[
        "accuracy",

        tf.keras.metrics.Precision(
            name="precision"
        ),

        tf.keras.metrics.Recall(
            name="recall"
        )
    ]
)


# ============================================================
# FINE-TUNING CALLBACKS
# ============================================================

fine_tune_checkpoint = ModelCheckpoint(
    MODEL_PATH,
    monitor="val_accuracy",
    mode="max",
    save_best_only=True,
    verbose=1
)


fine_tune_early_stopping = EarlyStopping(
    monitor="val_accuracy",
    mode="max",
    patience=5,
    restore_best_weights=True,
    verbose=1
)


fine_tune_reduce_lr = ReduceLROnPlateau(
    monitor="val_loss",
    factor=0.5,
    patience=2,
    min_lr=1e-7,
    verbose=1
)


# ============================================================
# FINE-TUNE
# ============================================================

fine_tune_epochs = 15


history_fine = model.fit(
    train_dataset,
    validation_data=validation_dataset,
    epochs=fine_tune_epochs,
    callbacks=[
        fine_tune_checkpoint,
        fine_tune_early_stopping,
        fine_tune_reduce_lr
    ]
)


# ============================================================
# SAVE EFFICIENTNETB3 TRAINING HISTORY
# ============================================================

CURVES_DIR = os.path.join(
    BASE_DIR,
    "evaluation",
    "curves"
)

os.makedirs(
    CURVES_DIR,
    exist_ok=True
)

# Combine initial training and fine-tuning histories

combined_history = {}

all_metrics = (
    set(history.history.keys())
    | set(history_fine.history.keys())
)

for metric in all_metrics:

    combined_history[metric] = (
        history.history.get(metric, [])
        + history_fine.history.get(metric, [])
    )


# Save training history as JSON

history_path = os.path.join(
    CURVES_DIR,
    "efficientnetb3_history.json"
)

with open(
    history_path,
    "w",
    encoding="utf-8"
) as file:

    json.dump(
        combined_history,
        file,
        indent=4
    )


print("\n" + "=" * 60)
print("EFFICIENTNETB3 TRAINING HISTORY SAVED SUCCESSFULLY")
print("=" * 60)

print(f"Location: {history_path}")

print(
    f"Total epochs recorded: "
    f"{len(combined_history['accuracy'])}"
)

print("=" * 60)


# ============================================================
# FINAL MODEL
# ============================================================

print("\n" + "=" * 60)
print("LOADING FINAL BEST MODEL")
print("=" * 60)

model = tf.keras.models.load_model(
    MODEL_PATH
)


print(
    "\nFinal model saved at:"
)

print(
    MODEL_PATH
)


# ============================================================
# FINAL VALIDATION EVALUATION
# ============================================================

print("\n" + "=" * 60)
print("FINAL VALIDATION EVALUATION")
print("=" * 60)

final_results = model.evaluate(
    validation_dataset,
    verbose=1
)


for name, value in zip(
    model.metrics_names,
    final_results
):

    print(
        f"{name}: {value:.4f}"
    )


# ============================================================
# COMPLETE
# ============================================================

print("\n" + "=" * 60)
print("EFFICIENTNETB3 TRAINING COMPLETE")
print("=" * 60)


print("\nModel:")
print(MODEL_PATH)

print("\nTraining history:")
print(history_path)

print("\nNext step:")
print("Run the EfficientNetB3 test evaluation.")
