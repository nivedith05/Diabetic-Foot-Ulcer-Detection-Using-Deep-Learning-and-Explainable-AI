import os
import json
from pathlib import Path

import tensorflow as tf
from tensorflow import keras

layers = keras.layers


# ============================================================
# CONFIGURATION
# ============================================================

BASE_DIR = Path(
    r"C:\Users\nived\Downloads\DFU-Detection-System"
)

DATASET_DIR = BASE_DIR / "dataset"

TRAIN_DIR = DATASET_DIR / "train"
VAL_DIR = DATASET_DIR / "validation"
TEST_DIR = DATASET_DIR / "test"

MODEL_DIR = BASE_DIR / "models"
MODEL_DIR.mkdir(parents=True, exist_ok=True)

IMAGE_SIZE = (224, 224)
BATCH_SIZE = 16

INITIAL_EPOCHS = 10
FINE_TUNE_EPOCHS = 15

SEED = 42


# ============================================================
# ENVIRONMENT
# ============================================================

print("=" * 60)
print("DFU DETECTION - TRANSFER LEARNING")
print("=" * 60)

print("\nTensorFlow:")
print(tf.__version__)

print("\nDevices:")
print(tf.config.list_physical_devices())


# ============================================================
# LOAD DATA
# ============================================================

print("\n" + "=" * 60)
print("LOADING DATA")
print("=" * 60)

train_ds = tf.keras.utils.image_dataset_from_directory(
    TRAIN_DIR,
    image_size=IMAGE_SIZE,
    batch_size=BATCH_SIZE,
    label_mode="binary",
    shuffle=True,
    seed=SEED
)

val_ds = tf.keras.utils.image_dataset_from_directory(
    VAL_DIR,
    image_size=IMAGE_SIZE,
    batch_size=BATCH_SIZE,
    label_mode="binary",
    shuffle=False
)

test_ds = tf.keras.utils.image_dataset_from_directory(
    TEST_DIR,
    image_size=IMAGE_SIZE,
    batch_size=BATCH_SIZE,
    label_mode="binary",
    shuffle=False
)

print("\nClass mapping:")
print(train_ds.class_names)

print("\nExpected mapping:")
print("0 = abnormal")
print("1 = normal")


# ============================================================
# PERFORMANCE
# ============================================================

AUTOTUNE = tf.data.AUTOTUNE

train_ds = train_ds.prefetch(AUTOTUNE)
val_ds = val_ds.prefetch(AUTOTUNE)
test_ds = test_ds.prefetch(AUTOTUNE)


# ============================================================
# DATA AUGMENTATION
# ============================================================

data_augmentation = keras.Sequential(
    [
        layers.RandomFlip("horizontal"),
        layers.RandomRotation(0.05),
        layers.RandomZoom(0.10),
        layers.RandomContrast(0.10),
    ],
    name="data_augmentation"
)


# ============================================================
# PRETRAINED MOBILENETV2
# ============================================================

print("\n" + "=" * 60)
print("LOADING IMAGENET-PRETRAINED MOBILENETV2")
print("=" * 60)

base_model = tf.keras.applications.MobileNetV2(
    input_shape=(224, 224, 3),
    include_top=False,
    weights="imagenet"
)


# Freeze the pretrained feature extractor
base_model.trainable = False


# ============================================================
# MODEL
# ============================================================

inputs = keras.Input(
    shape=(224, 224, 3)
)

x = data_augmentation(inputs)

# MobileNetV2 expects pixels in [-1, 1]
x = layers.Rescaling(
    1.0 / 127.5,
    offset=-1
)(x)

x = base_model(
    x,
    training=False
)

x = layers.GlobalAveragePooling2D()(x)

x = layers.Dropout(0.4)(x)

outputs = layers.Dense(
    1,
    activation="sigmoid"
)(x)

model = keras.Model(
    inputs,
    outputs
)


# ============================================================
# COMPILE - INITIAL TRAINING
# ============================================================

model.compile(
    optimizer=keras.optimizers.Adam(
        learning_rate=0.0001
    ),
    loss="binary_crossentropy",
    metrics=[
        "accuracy",
        keras.metrics.Precision(name="precision"),
        keras.metrics.Recall(name="recall")
    ]
)


print("\nModel created.")

model.summary()


# ============================================================
# CALLBACKS
# ============================================================

checkpoint_path = (
    MODEL_DIR / "mobilenetv2_best.keras"
)

callbacks = [

    keras.callbacks.ModelCheckpoint(
        checkpoint_path,
        monitor="val_accuracy",
        save_best_only=True,
        mode="max",
        verbose=1
    ),

    keras.callbacks.EarlyStopping(
        monitor="val_loss",
        patience=4,
        restore_best_weights=True,
        verbose=1
    ),

    keras.callbacks.ReduceLROnPlateau(
        monitor="val_loss",
        factor=0.5,
        patience=2,
        min_lr=1e-7,
        verbose=1
    )
]


# ============================================================
# PHASE 1 - TRAIN CLASSIFIER
# ============================================================

print("\n" + "=" * 60)
print("PHASE 1: TRAINING CLASSIFIER")
print("=" * 60)

history1 = model.fit(
    train_ds,
    validation_data=val_ds,
    epochs=INITIAL_EPOCHS,
    callbacks=callbacks
)


# ============================================================
# PHASE 2 - FINE-TUNING
# ============================================================

print("\n" + "=" * 60)
print("PHASE 2: FINE-TUNING")
print("=" * 60)

base_model.trainable = True


# Freeze the earlier MobileNet layers.
# Fine-tune only the later layers.

fine_tune_from = 100

for layer in base_model.layers[:fine_tune_from]:
    layer.trainable = False


model.compile(
    optimizer=keras.optimizers.Adam(
        learning_rate=1e-5
    ),
    loss="binary_crossentropy",
    metrics=[
        "accuracy",
        keras.metrics.Precision(name="precision"),
        keras.metrics.Recall(name="recall")
    ]
)


history2 = model.fit(
    train_ds,
    validation_data=val_ds,
    epochs=FINE_TUNE_EPOCHS,
    callbacks=callbacks
)

# ============================================================
# SAVE MOBILENETV2 TRAINING HISTORY
# ============================================================

CURVES_DIR = BASE_DIR / "evaluation" / "curves"
CURVES_DIR.mkdir(parents=True, exist_ok=True)

# Combine initial training and fine-tuning histories
combined_history = {}

all_metrics = set(history1.history.keys()) | set(history2.history.keys())

for metric in all_metrics:
    combined_history[metric] = (
        history1.history.get(metric, [])
        + history2.history.get(metric, [])
    )

# Save training history as JSON
history_path = CURVES_DIR / "mobilenetv2_history.json"

with open(history_path, "w", encoding="utf-8") as file:
    json.dump(combined_history, file, indent=4)

print("\n" + "=" * 55)
print("MOBILENETV2 TRAINING HISTORY SAVED SUCCESSFULLY")
print("=" * 55)
print(f"Location: {history_path}")
print(f"Total epochs recorded: {len(combined_history['accuracy'])}")
print("=" * 55)

# ============================================================
# LOAD BEST MODEL
# ============================================================

print("\n" + "=" * 60)
print("LOADING BEST MODEL")
print("=" * 60)

best_model = keras.models.load_model(
    checkpoint_path
)


# ============================================================
# TEST EVALUATION
# ============================================================

print("\n" + "=" * 60)
print("FINAL TEST SET EVALUATION")
print("=" * 60)

results = best_model.evaluate(
    test_ds,
    verbose=1
)

for name, value in zip(
    best_model.metrics_names,
    results
):
    print(
        f"{name}: {value:.4f}"
    )


# ============================================================
# SAVE FINAL MODEL
# ============================================================

final_path = (
    MODEL_DIR / "dfu_mobilenetv2.keras"
)

best_model.save(
    final_path
)

print("\nFinal model saved to:")
print(final_path)

print("\n" + "=" * 60)
print("TRAINING COMPLETE")
print("=" * 60)