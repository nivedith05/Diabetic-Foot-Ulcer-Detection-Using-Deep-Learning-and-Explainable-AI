import os
import sys
import numpy as np
import tensorflow as tf


# ============================================================
# CONFIGURATION
# ============================================================

BASE_DIR = r"C:\Users\nived\Downloads\DFU-Detection-System"

MODEL_PATH = os.path.join(
    BASE_DIR,
    "models",
    "dfu_vgg16.keras"
)

IMG_SIZE = (224, 224)


# ============================================================
# CHECK COMMAND-LINE ARGUMENT
# ============================================================

if len(sys.argv) < 2:

    print("=" * 60)
    print("DFU DETECTION SYSTEM")
    print("=" * 60)

    print("\nUsage:")
    print(
        "python predict.py <image_path>"
    )

    print("\nExample:")
    print(
        r'python predict.py "C:\path\to\image.jpg"'
    )

    sys.exit(1)


IMAGE_PATH = sys.argv[1]


# ============================================================
# CHECK FILES
# ============================================================

if not os.path.exists(MODEL_PATH):

    print(
        "\nERROR: VGG16 model not found:"
    )

    print(
        MODEL_PATH
    )

    sys.exit(1)


if not os.path.exists(IMAGE_PATH):

    print(
        "\nERROR: Image not found:"
    )

    print(
        IMAGE_PATH
    )

    sys.exit(1)


# ============================================================
# LOAD MODEL
# ============================================================

print("=" * 60)
print("DFU DETECTION SYSTEM")
print("=" * 60)

print("\nLoading VGG16 model...")

model = tf.keras.models.load_model(
    MODEL_PATH
)

print("Model loaded successfully.")


# ============================================================
# LOAD IMAGE
# ============================================================

print("\nLoading image...")

image = tf.keras.utils.load_img(
    IMAGE_PATH,
    target_size=IMG_SIZE
)


image_array = (
    tf.keras.utils.img_to_array(
        image
    )
)


# ============================================================
# VGG16 PREPROCESSING
# ============================================================

image_array = (
    tf.keras.applications.vgg16
    .preprocess_input(
        image_array
    )
)


image_batch = np.expand_dims(
    image_array,
    axis=0
)


# ============================================================
# PREDICTION
# ============================================================

print("Running prediction...")

prediction = model.predict(
    image_batch,
    verbose=0
)[0][0]


# ============================================================
# CLASSIFICATION
# ============================================================

# Dataset mapping:
#
# 0 = abnormal
# 1 = normal

if prediction >= 0.5:

    predicted_class = "NORMAL"

    confidence = prediction

else:

    predicted_class = "ABNORMAL"

    confidence = 1 - prediction


# ============================================================
# RESULT
# ============================================================

print("\n" + "=" * 60)
print("PREDICTION RESULT")
print("=" * 60)

print(
    "\nImage:"
)

print(
    IMAGE_PATH
)

print(
    "\nPrediction:"
)

print(
    predicted_class
)

print(
    "\nConfidence:"
)

print(
    f"{confidence * 100:.2f}%"
)


print("\n" + "=" * 60)

print(
    "NOTE: This is an academic/research prototype "
    "and does not replace professional medical diagnosis."
)

print("=" * 60)