from pathlib import Path
from sklearn.model_selection import train_test_split
import shutil
import random

# ============================================================
# CONFIGURATION
# ============================================================

SOURCE_DIR = Path(
    r"C:\Users\nived\Downloads\DFU-Detection-System\Patches"
)

OUTPUT_DIR = Path(
    r"C:\Users\nived\Downloads\DFU-Detection-System\dataset"
)

RANDOM_STATE = 42

VALID_EXTENSIONS = {
    ".jpg",
    ".jpeg",
    ".png",
    ".bmp",
    ".webp"
}


# ============================================================
# CLASS MAPPING
# ============================================================

CLASS_MAPPING = {
    "Abnormal(Ulcer)": "abnormal",
    "Normal(Healthy skin)": "normal"
}


# ============================================================
# CHECK SOURCE DATASET
# ============================================================

print("=" * 60)
print("DFU DATASET PREPARATION")
print("=" * 60)

if not SOURCE_DIR.exists():
    print("ERROR: Source dataset not found:")
    print(SOURCE_DIR)
    exit()

print("\nSource dataset:")
print(SOURCE_DIR)


# ============================================================
# COLLECT IMAGES
# ============================================================

all_data = []

for original_class, new_class in CLASS_MAPPING.items():

    class_dir = SOURCE_DIR / original_class

    if not class_dir.exists():
        print(f"\nERROR: Missing folder: {class_dir}")
        exit()

    images = [
        file
        for file in class_dir.iterdir()
        if file.is_file()
        and file.suffix.lower() in VALID_EXTENSIONS
    ]

    print(f"\n{original_class}: {len(images)} images")

    for image in images:
        all_data.append((image, new_class))


# ============================================================
# CREATE TRAIN / VALIDATION / TEST SPLITS
# ============================================================

print("\n" + "=" * 60)
print("CREATING DATA SPLITS")
print("=" * 60)

paths = [item[0] for item in all_data]
labels = [item[1] for item in all_data]


# First split:
# 70% training
# 30% temporary

train_paths, temp_paths, train_labels, temp_labels = train_test_split(
    paths,
    labels,
    test_size=0.30,
    random_state=RANDOM_STATE,
    stratify=labels
)


# Second split:
# Half validation
# Half test
#
# Therefore:
# 70% train
# 15% validation
# 15% test

val_paths, test_paths, val_labels, test_labels = train_test_split(
    temp_paths,
    temp_labels,
    test_size=0.50,
    random_state=RANDOM_STATE,
    stratify=temp_labels
)


print(f"\nTraining images:   {len(train_paths)}")
print(f"Validation images: {len(val_paths)}")
print(f"Testing images:    {len(test_paths)}")
print(f"Total:             {len(paths)}")


# ============================================================
# FUNCTION TO COPY DATA
# ============================================================

def copy_images(image_paths, labels, split_name):

    for image_path, label in zip(image_paths, labels):

        destination_dir = OUTPUT_DIR / split_name / label

        destination_dir.mkdir(
            parents=True,
            exist_ok=True
        )

        destination = destination_dir / image_path.name

        # Avoid accidental overwriting
        if destination.exists():

            random_name = (
                image_path.stem
                + "_copy"
                + image_path.suffix
            )

            destination = destination_dir / random_name

        shutil.copy2(
            image_path,
            destination
        )


# ============================================================
# CREATE DATASET
# ============================================================

print("\nCopying training images...")
copy_images(
    train_paths,
    train_labels,
    "train"
)

print("Copying validation images...")
copy_images(
    val_paths,
    val_labels,
    "validation"
)

print("Copying test images...")
copy_images(
    test_paths,
    test_labels,
    "test"
)


# ============================================================
# FINAL SUMMARY
# ============================================================

print("\n" + "=" * 60)
print("DATASET PREPARATION COMPLETE")
print("=" * 60)

for split in ["train", "validation", "test"]:

    print(f"\n{split.upper()}")

    for label in ["abnormal", "normal"]:

        folder = OUTPUT_DIR / split / label

        count = len([
            f for f in folder.iterdir()
            if f.is_file()
        ])

        print(f"  {label}: {count}")

print("\nDataset created at:")
print(OUTPUT_DIR)

print("\nOriginal dataset has NOT been modified.")