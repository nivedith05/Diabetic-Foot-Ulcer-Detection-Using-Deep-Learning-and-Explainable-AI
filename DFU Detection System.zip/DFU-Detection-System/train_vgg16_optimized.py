
import os
import json
from pathlib import Path

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
    roc_auc_score
)


# ============================================================
# 1. CONFIGURATION
# ============================================================

BASE_DIR = Path(
    r"C:\Users\nived\Downloads\DFU-Detection-System"
)

DATASET_DIR = BASE_DIR / "dataset"

TRAIN_DIR = DATASET_DIR / "train"
VAL_DIR = DATASET_DIR / "validation"
TEST_DIR = DATASET_DIR / "test"

MODEL_DIR = BASE_DIR / "models"
EVALUATION_DIR = BASE_DIR / "evaluation"
CURVES_DIR = EVALUATION_DIR / "curves"

MODEL_DIR.mkdir(parents=True, exist_ok=True)
EVALUATION_DIR.mkdir(parents=True, exist_ok=True)
CURVES_DIR.mkdir(parents=True, exist_ok=True)

IMAGE_SIZE = (224, 224)
BATCH_SIZE = 16

INITIAL_EPOCHS = 12
FINE_TUNE_EPOCHS = 20

INITIAL_LR = 1e-4
FINE_TUNE_LR = 5e-6

SEED = 42
THRESHOLD = 0.5

tf.keras.utils.set_random_seed(SEED)


# ============================================================
# 2. ENVIRONMENT
# ============================================================

print("=" * 65)
print("OPTIMIZED VGG16 - DFU CLASSIFICATION")
print("=" * 65)

print("TensorFlow:", tf.__version__)
print("Devices:", tf.config.list_physical_devices())

for directory in [TRAIN_DIR, VAL_DIR, TEST_DIR]:
    if not directory.exists():
        raise FileNotFoundError(
            f"Dataset directory not found: {directory}"
        )


# ============================================================
# 3. LOAD DATASETS
# ============================================================

print("\nLoading datasets...")

train_ds = keras.utils.image_dataset_from_directory(
    TRAIN_DIR,
    image_size=IMAGE_SIZE,
    batch_size=BATCH_SIZE,
    label_mode="binary",
    shuffle=True,
    seed=SEED
)

val_ds = keras.utils.image_dataset_from_directory(
    VAL_DIR,
    image_size=IMAGE_SIZE,
    batch_size=BATCH_SIZE,
    label_mode="binary",
    shuffle=False
)

test_ds = keras.utils.image_dataset_from_directory(
    TEST_DIR,
    image_size=IMAGE_SIZE,
    batch_size=BATCH_SIZE,
    label_mode="binary",
    shuffle=False
)

class_names = train_ds.class_names

print("Class mapping:", class_names)

if [name.lower() for name in class_names] != [
    "abnormal", "normal"
]:
    raise ValueError(
        "Expected alphabetical class mapping: "
        "0 = abnormal, 1 = normal. "
        f"Found: {class_names}"
    )

if train_ds.class_names != val_ds.class_names:
    raise ValueError("Training and validation mappings differ.")

if train_ds.class_names != test_ds.class_names:
    raise ValueError("Training and test mappings differ.")


AUTOTUNE = tf.data.AUTOTUNE

train_ds = train_ds.prefetch(AUTOTUNE)
val_ds = val_ds.prefetch(AUTOTUNE)
test_ds = test_ds.prefetch(AUTOTUNE)


# ============================================================
# 4. DATA AUGMENTATION
# ============================================================

data_augmentation = keras.Sequential(
    [
        layers.RandomFlip("horizontal"),
        layers.RandomRotation(0.04),
        layers.RandomZoom(0.08),
        layers.RandomContrast(0.08)
    ],
    name="data_augmentation"
)


# ============================================================
# 5. LOAD PRETRAINED VGG16
# ============================================================

print("\nLoading ImageNet-pretrained VGG16...")

base_model = keras.applications.VGG16(
    input_shape=(224, 224, 3),
    include_top=False,
    weights="imagenet"
)

base_model.trainable = False


# ============================================================
# 6. BUILD CLASSIFICATION MODEL
# ============================================================

inputs = keras.Input(
    shape=(224, 224, 3),
    name="input_image"
)

x = data_augmentation(inputs)

# Correct VGG16 preprocessing
x = keras.applications.vgg16.preprocess_input(x)

x = base_model(
    x,
    training=False
)

x = layers.GlobalAveragePooling2D()(x)

x = layers.Dense(
    256,
    activation="relu",
    kernel_regularizer=keras.regularizers.l2(1e-4)
)(x)

x = layers.Dropout(0.4)(x)

outputs = layers.Dense(
    1,
    activation="sigmoid",
    name="prediction"
)(x)

model = keras.Model(
    inputs,
    outputs,
    name="Optimized_VGG16_DFU"
)


# ============================================================
# 7. COMPILE MODEL
# ============================================================

def compile_model(learning_rate):

    model.compile(
        optimizer=keras.optimizers.Adam(
            learning_rate=learning_rate
        ),
        loss="binary_crossentropy",
        metrics=[
            keras.metrics.BinaryAccuracy(
                name="accuracy"
            )
        ]
    )


compile_model(INITIAL_LR)

model.summary()


# ============================================================
# 8. CUSTOM VALIDATION METRICS
# ============================================================

class ValidationMetricsCallback(keras.callbacks.Callback):

    def __init__(self, validation_data, checkpoint_path):

        super().__init__()

        self.validation_data = validation_data
        self.checkpoint_path = checkpoint_path
        self.best_f1 = -1.0

        self.y_true = np.concatenate(
            [
                labels.numpy().reshape(-1)
                for _, labels in validation_data
            ]
        ).astype(int)

    def on_epoch_end(self, epoch, logs=None):

        logs = logs if logs is not None else {}

        probabilities = self.model.predict(
            self.validation_data,
            verbose=0
        ).reshape(-1)

        # Output >= 0.5 means class 1 (normal).
        predictions = (
            probabilities >= THRESHOLD
        ).astype(int)

        # Abnormal is class 0.
        precision = precision_score(
            self.y_true,
            predictions,
            pos_label=0,
            zero_division=0
        )

        recall = recall_score(
            self.y_true,
            predictions,
            pos_label=0,
            zero_division=0
        )

        f1 = f1_score(
            self.y_true,
            predictions,
            pos_label=0,
            zero_division=0
        )

        logs["val_abnormal_precision"] = precision
        logs["val_abnormal_recall"] = recall
        logs["val_abnormal_f1"] = f1

        print(
            f"\nValidation abnormal precision: {precision:.4f}"
            f"\nValidation abnormal recall: {recall:.4f}"
            f"\nValidation abnormal F1: {f1:.4f}"
        )

        # Save the best model using validation F1.
        if f1 > self.best_f1:

            self.best_f1 = f1

            self.model.save(
                self.checkpoint_path
            )

            print(
                f"\nBest VGG16 checkpoint saved."
                f"\nValidation F1: {self.best_f1:.4f}"
            )


checkpoint_path = (
    MODEL_DIR / "vgg16_optimized_best.keras"
)

metrics_callback = ValidationMetricsCallback(
    val_ds,
    checkpoint_path
)


# ============================================================
# 9. CALLBACKS
# ============================================================

callbacks = [

    metrics_callback,

    keras.callbacks.ReduceLROnPlateau(
        monitor="val_loss",
        factor=0.5,
        patience=2,
        min_lr=1e-7,
        verbose=1
    ),

    keras.callbacks.EarlyStopping(
        monitor="val_abnormal_f1",
        mode="max",
        patience=6,
        restore_best_weights=True,
        verbose=1
    )
]


# ============================================================
# 10. PHASE 1 - CLASSIFICATION HEAD TRAINING
# ============================================================

print("\n" + "=" * 65)
print("PHASE 1: TRAINING CLASSIFICATION HEAD")
print("=" * 65)

history1 = model.fit(
    train_ds,
    validation_data=val_ds,
    epochs=INITIAL_EPOCHS,
    callbacks=callbacks
)


# ============================================================
# 11. PHASE 2 - FINE-TUNING
# ============================================================

print("\n" + "=" * 65)
print("PHASE 2: FINE-TUNING DEEP VGG16 LAYERS")
print("=" * 65)

base_model.trainable = True

# Fine-tune VGG16 block 4 and block 5.
# Keep earlier feature extraction layers frozen.

for layer in base_model.layers:

    if layer.name.startswith(
        ("block4_", "block5_")
    ):
        layer.trainable = True

    else:
        layer.trainable = False

print("\nTrainable VGG16 layers:")

for layer in base_model.layers:

    if layer.trainable:
        print(layer.name)


compile_model(FINE_TUNE_LR)

history2 = model.fit(
    train_ds,
    validation_data=val_ds,
    epochs=FINE_TUNE_EPOCHS,
    callbacks=callbacks
)


# ============================================================
# 12. SAVE TRAINING HISTORY
# ============================================================

combined_history = {}

all_keys = set(history1.history) | set(history2.history)

for key in all_keys:

    combined_history[key] = (
        history1.history.get(key, [])
        + history2.history.get(key, [])
    )

history_path = CURVES_DIR / "vgg16_optimized_history.json"

with open(history_path, "w", encoding="utf-8") as file:

    json.dump(
        combined_history,
        file,
        indent=4
    )

print("\nTraining history saved:", history_path)


# ============================================================
# 13. LOAD BEST VALIDATION CHECKPOINT
# ============================================================

print("\nLoading best VGG16 checkpoint...")

best_model = keras.models.load_model(
    checkpoint_path
)


# ============================================================
# 14. FINAL TEST EVALUATION
# ============================================================

print("\n" + "=" * 65)
print("FINAL TEST SET EVALUATION")
print("=" * 65)

y_true = np.concatenate(
    [
        labels.numpy().reshape(-1)
        for _, labels in test_ds
    ]
).astype(int)

probabilities = best_model.predict(
    test_ds,
    verbose=1
).reshape(-1)

y_pred = (
    probabilities >= THRESHOLD
).astype(int)

accuracy = accuracy_score(y_true, y_pred)

precision = precision_score(
    y_true,
    y_pred,
    pos_label=0,
    zero_division=0
)

recall = recall_score(
    y_true,
    y_pred,
    pos_label=0,
    zero_division=0
)

f1 = f1_score(
    y_true,
    y_pred,
    pos_label=0,
    zero_division=0
)

auc = roc_auc_score(
    (y_true == 0).astype(int),
    1.0 - probabilities
)

print("\nFINAL VGG16 RESULTS")

print(f"Accuracy:  {accuracy:.6f}")
print(f"Precision: {precision:.6f}")
print(f"Recall:    {recall:.6f}")
print(f"F1-score:  {f1:.6f}")
print(f"AUC:       {auc:.6f}")


# ============================================================
# 15. CONFUSION MATRIX
# ============================================================

cm = confusion_matrix(
    y_true,
    y_pred,
    labels=[0, 1]
)

print("\nConfusion Matrix")
print("Rows = Actual, Columns = Predicted")
print("Class order: Abnormal, Normal")
print(cm)


# ============================================================
# 16. CLASSIFICATION REPORT
# ============================================================

report = classification_report(
    y_true,
    y_pred,
    labels=[0, 1],
    target_names=["Abnormal", "Normal"],
    zero_division=0
)

print("\nClassification Report:")
print(report)


# ============================================================
# 17. SAVE FINAL MODEL
# ============================================================

final_model_path = (
    MODEL_DIR / "dfu_vgg16_optimized.keras"
)

best_model.save(final_model_path)


# ============================================================
# 18. SAVE TEST METRICS
# ============================================================

results = {
    "model": "VGG16 Optimized",
    "accuracy": float(accuracy),
    "precision_abnormal": float(precision),
    "recall_abnormal": float(recall),
    "f1_abnormal": float(f1),
    "auc_abnormal": float(auc),
    "confusion_matrix": cm.tolist(),
    "classification_report": report,
    "threshold": THRESHOLD
}

results_path = EVALUATION_DIR / "vgg16_optimized_results.json"

with open(results_path, "w", encoding="utf-8") as file:

    json.dump(
        results,
        file,
        indent=4
    )


print("\n" + "=" * 65)
print("OPTIMIZED VGG16 TRAINING COMPLETED")
print("=" * 65)

print("Best checkpoint:", checkpoint_path)
print("Final model:", final_model_path)
print("Training history:", history_path)
print("Evaluation results:", results_path)

print("=" * 65)
