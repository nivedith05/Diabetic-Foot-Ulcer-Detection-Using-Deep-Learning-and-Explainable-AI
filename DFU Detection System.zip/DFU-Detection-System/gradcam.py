
from pathlib import Path

import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt


# ============================================================
# CONFIGURATION
# ============================================================

BASE_DIR = Path(
    r"C:\Users\nived\Downloads\DFU-Detection-System"
)

MODEL_PATH = BASE_DIR / "models" / "dfu_vgg16.keras"
DATASET_DIR = BASE_DIR / "dataset"
OUTPUT_DIR = BASE_DIR / "evaluation" / "gradcam"

IMAGE_SIZE = (224, 224)

VALID_EXTENSIONS = {
    ".jpg", ".jpeg", ".png", ".bmp", ".webp"
}

# IMPORTANT:
# This code assumes the model has one sigmoid output:
# output probability = probability of NORMAL (class 1).
#
# Class mapping used by your original script:
# 0 = abnormal
# 1 = normal


# ============================================================
# CHECK PATHS AND LOAD MODEL
# ============================================================

print("=" * 65)
print("              DFU GRAD-CAM EXPLAINABILITY")
print("=" * 65)

if not MODEL_PATH.is_file():
    raise FileNotFoundError(
        f"\nModel file not found:\n{MODEL_PATH}\n"
        "Check that dfu_vgg16.keras exists in the models folder."
    )

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

print("\nLoading VGG16 model...")

model = tf.keras.models.load_model(MODEL_PATH)

print("Model loaded successfully.")
print("\nModel input shape:", model.input_shape)
print("Model output shape:", model.output_shape)


# ============================================================
# FIND THE VGG16 BASE MODEL
# ============================================================

base_model = None

for layer in model.layers:
    if isinstance(layer, tf.keras.Model):
        if "vgg16" in layer.name.lower():
            base_model = layer
            break

if base_model is None:
    raise RuntimeError(
        "Could not find a nested VGG16 model inside the loaded model. "
        "This script expects the VGG16 base model to be a nested model."
    )

print("\nVGG16 base model found:", base_model.name)


# ============================================================
# FIND THE LAST CONVOLUTIONAL LAYER
# ============================================================

conv_layers = [
    layer
    for layer in base_model.layers
    if isinstance(layer, tf.keras.layers.Conv2D)
]

if not conv_layers:
    raise RuntimeError("No convolutional layers were found in VGG16.")

last_conv_layer = conv_layers[-1]
last_conv_index = base_model.layers.index(last_conv_layer)

print("Grad-CAM convolutional layer:", last_conv_layer.name)


# ============================================================
# IDENTIFY THE LAYERS AFTER THE CONVOLUTIONAL LAYER
# ============================================================

# These layers include the remaining VGG16 operations,
# such as the final max-pooling layer.
base_tail_layers = base_model.layers[last_conv_index + 1:]

# Find the classification layers after the nested VGG16 model.
head_layers = []
found_base = False

for layer in model.layers:
    if layer == base_model:
        found_base = True
        continue

    if found_base:
        head_layers.append(layer)

print("\nRemaining VGG16 layers:")
for layer in base_tail_layers:
    print(" -", layer.name)

print("\nClassification head:")
for layer in head_layers:
    print(" -", layer.name)


# ============================================================
# CREATE FEATURE MODEL
# ============================================================

feature_model = tf.keras.Model(
    inputs=base_model.input,
    outputs=last_conv_layer.output
)

print("\nGrad-CAM feature model created.")


# ============================================================
# GRAD-CAM HEATMAP FUNCTION
# ============================================================

def make_gradcam_heatmap(processed_image, target_class):
    """
    Generate a Grad-CAM heatmap for the predicted class.

    target_class:
        'normal'   -> explain the normal-class score
        'abnormal' -> explain the abnormal-class score
    """

    image_tensor = tf.convert_to_tensor(
        processed_image[np.newaxis, ...],
        dtype=tf.float32
    )

    with tf.GradientTape() as tape:

        # Get feature maps from the last convolutional layer.
        conv_outputs = feature_model(
            image_tensor,
            training=False
        )

        # Continue through the remaining VGG16 layers.
        x = conv_outputs

        for layer in base_tail_layers:
            x = layer(x, training=False)

        # Continue through the classification head.
        for layer in head_layers:
            x = layer(x, training=False)

        # This implementation expects a single sigmoid output.
        if x.shape[-1] != 1:
            raise ValueError(
                "Expected a model with one sigmoid output. "
                f"Actual output shape: {x.shape}"
            )

        normal_score = x[:, 0]

        if target_class == "normal":
            class_score = normal_score
        else:
            class_score = 1.0 - normal_score

    # Calculate gradients of the target score with respect
    # to the convolutional feature maps.
    gradients = tape.gradient(class_score, conv_outputs)

    if gradients is None:
        raise RuntimeError(
            "Gradients are None. Check the model architecture "
            "and the connection between the convolutional layer "
            "and classification output."
        )

    # Average gradients across the spatial dimensions.
    pooled_gradients = tf.reduce_mean(
        gradients,
        axis=(0, 1, 2)
    )

    # Select feature maps for the current image.
    feature_maps = conv_outputs[0]

    # Weight each feature map by its average gradient.
    heatmap = tf.reduce_sum(
        feature_maps * pooled_gradients,
        axis=-1
    )

    # Retain positive contributions.
    heatmap = tf.maximum(heatmap, 0)

    # Normalize to the range 0 to 1.
    max_value = tf.reduce_max(heatmap)

    heatmap = heatmap / (
        max_value + tf.keras.backend.epsilon()
    )

    return heatmap.numpy()


# ============================================================
# PROCESS A SINGLE IMAGE
# ============================================================

def process_image(image_path, output_path):
    """Predict one image and save its Grad-CAM visualization."""

    image_path = Path(image_path)
    output_path = Path(output_path)

    print("\n" + "-" * 65)
    print("Processing:", image_path)

    # Load and resize the selected image.
    image = tf.keras.utils.load_img(
        image_path,
        target_size=IMAGE_SIZE,
        color_mode="rgb"
    )

    image_array = tf.keras.utils.img_to_array(image)
    original_image = image_array.copy()

    # Apply the same preprocessing used by VGG16.
    processed_image = (
        tf.keras.applications.vgg16.preprocess_input(
            image_array.copy()
        )
    )

    # Predict using the complete trained model.
    prediction_array = model.predict(
        processed_image[np.newaxis, ...],
        verbose=0
    )

    prediction = float(prediction_array[0][0])

    # Original class mapping:
    # 0 = abnormal, 1 = normal.
    # Assumes the sigmoid output is the probability of normal.
    if prediction >= 0.5:
        predicted_class = "normal"
        confidence = prediction
    else:
        predicted_class = "abnormal"
        confidence = 1.0 - prediction

    print("Predicted class:", predicted_class)
    print(f"Confidence: {confidence * 100:.2f}%")

    # Generate a heatmap for the predicted class.
    heatmap = make_gradcam_heatmap(
        processed_image,
        target_class=predicted_class
    )

    # Resize the heatmap to the original display dimensions.
    heatmap_resized = tf.image.resize(
        heatmap[..., np.newaxis],
        IMAGE_SIZE
    ).numpy().squeeze()

    # Create a three-panel visualization.
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))

    axes[0].imshow(original_image.astype(np.uint8))
    axes[0].set_title("Original Image")
    axes[0].axis("off")

    axes[1].imshow(heatmap_resized, cmap="jet", vmin=0, vmax=1)
    axes[1].set_title("Grad-CAM Heatmap")
    axes[1].axis("off")

    axes[2].imshow(original_image.astype(np.uint8))
    axes[2].imshow(
        heatmap_resized,
        cmap="jet",
        alpha=0.45,
        vmin=0,
        vmax=1
    )
    axes[2].set_title(
        f"Prediction: {predicted_class.upper()}\n"
        f"Confidence: {confidence * 100:.2f}%"
    )
    axes[2].axis("off")

    fig.tight_layout()

    output_path.parent.mkdir(parents=True, exist_ok=True)

    fig.savefig(
        output_path,
        dpi=300,
        bbox_inches="tight"
    )

    plt.close(fig)

    print("Saved visualization:", output_path)

    return predicted_class, confidence


# ============================================================
# FIND DATASET IMAGES
# ============================================================

def find_dataset_images(selected_splits):
    """
    Find images inside dataset split folders.

    Recognized split names:
    train, training, val, valid, validation, test, testing
    """

    if not DATASET_DIR.is_dir():
        raise FileNotFoundError(
            f"Dataset directory not found:\n{DATASET_DIR}"
        )

    split_aliases = {
        "train": {"train", "training"},
        "validation": {"val", "valid", "validation"},
        "test": {"test", "testing"}
    }

    accepted_names = set()

    for split in selected_splits:
        accepted_names.update(split_aliases[split])

    image_paths = []

    for path in DATASET_DIR.rglob("*"):
        if not path.is_file():
            continue

        if path.suffix.lower() not in VALID_EXTENSIONS:
            continue

        relative_parts = path.relative_to(DATASET_DIR).parts[:-1]

        if any(
            part.lower() in accepted_names
            for part in relative_parts
        ):
            image_paths.append(path)

    return sorted(image_paths)


# ============================================================
# SELECT IMAGES
# ============================================================

def choose_dataset_image(image_paths):
    """Display dataset images and let the user choose one."""

    if not image_paths:
        raise FileNotFoundError(
            "No images were found in the selected dataset folder."
        )

    print(f"\nFound {len(image_paths)} images.\n")

    for index, path in enumerate(image_paths, start=1):
        relative_path = path.relative_to(DATASET_DIR)
        print(f"{index}. {relative_path}")

    while True:
        selection = input(
            "\nEnter the image number you want to analyze: "
        ).strip()

        if selection.isdigit():
            selected_index = int(selection)

            if 1 <= selected_index <= len(image_paths):
                return image_paths[selected_index - 1]

        print(
            f"Invalid selection. Enter a number from "
            f"1 to {len(image_paths)}."
        )


# ============================================================
# TERMINAL MENU
# ============================================================

def main():
    print("\nChoose an option:")
    print("1. Analyze an external image using its path")
    print("2. Select one image from the dataset")
    print("3. Analyze an entire dataset split")

    choice = input("\nEnter your choice (1, 2, or 3): ").strip()

    # --------------------------------------------------------
    # OPTION 1: EXTERNAL IMAGE
    # --------------------------------------------------------
    if choice == "1":

        image_input = input(
            "\nPaste the full image path and press Enter:\n> "
        ).strip().strip('"').strip("'")

        if not image_input:
            raise ValueError("No image path was provided.")

        image_path = Path(image_input)

        if not image_path.is_file():
            raise FileNotFoundError(
                f"Image not found:\n{image_path}"
            )

        if image_path.suffix.lower() not in VALID_EXTENSIONS:
            raise ValueError("Unsupported image format.")

        output_path = (
            OUTPUT_DIR / f"gradcam_{image_path.stem}.png"
        )

        process_image(image_path, output_path)

    # --------------------------------------------------------
    # OPTION 2: ONE DATASET IMAGE
    # --------------------------------------------------------
    elif choice == "2":

        print("\nChoose a dataset split:")
        print("1. Training")
        print("2. Validation")
        print("3. Test")
        print("4. Entire dataset")

        split_choice = input(
            "\nEnter your choice (1, 2, 3, or 4): "
        ).strip()

        split_options = {
            "1": ["train"],
            "2": ["validation"],
            "3": ["test"],
            "4": ["train", "validation", "test"]
        }

        if split_choice not in split_options:
            raise ValueError("Invalid dataset split selection.")

        image_paths = find_dataset_images(
            split_options[split_choice]
        )

        image_path = choose_dataset_image(image_paths)

        relative_path = image_path.relative_to(DATASET_DIR)
        safe_name = "_".join(relative_path.with_suffix("").parts)

        output_path = OUTPUT_DIR / f"gradcam_{safe_name}.png"

        process_image(image_path, output_path)

    # --------------------------------------------------------
    # OPTION 3: BATCH DATASET ANALYSIS
    # --------------------------------------------------------
    elif choice == "3":

        print("\nChoose a dataset split:")
        print("1. Training")
        print("2. Validation")
        print("3. Test")
        print("4. Entire dataset")

        split_choice = input(
            "\nEnter your choice (1, 2, 3, or 4): "
        ).strip()

        split_options = {
            "1": ["train"],
            "2": ["validation"],
            "3": ["test"],
            "4": ["train", "validation", "test"]
        }

        if split_choice not in split_options:
            raise ValueError("Invalid dataset split selection.")

        image_paths = find_dataset_images(
            split_options[split_choice]
        )

        if not image_paths:
            raise FileNotFoundError(
                "No images were found in the selected dataset split."
            )

        print(f"\nFound {len(image_paths)} images to process.")

        successful = 0
        failed = 0

        for index, image_path in enumerate(image_paths, start=1):

            relative_path = image_path.relative_to(DATASET_DIR)
            safe_name = "_".join(
                relative_path.with_suffix("").parts
            )

            output_path = (
                OUTPUT_DIR / f"gradcam_{safe_name}.png"
            )

            print(f"\nImage {index} of {len(image_paths)}")

            try:
                process_image(image_path, output_path)
                successful += 1

            except Exception as error:
                failed += 1
                print("Could not process this image:", error)

        print("\n" + "=" * 65)
        print("BATCH ANALYSIS COMPLETE")
        print("=" * 65)
        print("Total images:", len(image_paths))
        print("Successful:", successful)
        print("Failed:", failed)

    else:
        raise ValueError("Invalid choice. Enter 1, 2, or 3.")

    print("\nOutput folder:", OUTPUT_DIR)
    print("Analysis finished.")


# ============================================================
# RUN PROGRAM
# ============================================================

if __name__ == "__main__":
    main()
