
from pathlib import Path

import numpy as np
import pandas as pd
import tensorflow as tf
import matplotlib.pyplot as plt

from sklearn.metrics import (
    confusion_matrix,
    roc_curve,
    roc_auc_score,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    classification_report
)


# ============================================================
# 1. CONFIGURATION
# ============================================================

BASE_DIR = Path(
    r"C:\Users\nived\Downloads\DFU-Detection-System"
)

TEST_DIR = BASE_DIR / "dataset" / "test"
MODEL_DIR = BASE_DIR / "models"
OUTPUT_DIR = BASE_DIR / "evaluation"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

BATCH_SIZE = 16

# Model filenames
MODEL_FILES = {
    "VGG16": MODEL_DIR / "dfu_vgg16_optimized.keras",
    "MobileNetV2": MODEL_DIR / "dfu_mobilenetv2.keras",
    "EfficientNetB3": MODEL_DIR / "efficientnetb3_best.keras"
}


# ============================================================
# 2. CHECK MODEL FILES
# ============================================================

print("=" * 70)
print("DIABETIC FOOT ULCER DETECTION")
print("THREE MODEL EVALUATION AND COMPARISON")
print("=" * 70)

print("\nChecking model files...")

for model_name, model_path in MODEL_FILES.items():

    if not model_path.exists():
        raise FileNotFoundError(
            f"\n{model_name} model not found:\n{model_path}\n"
            "Please check the model filename and models folder."
        )

    print(f"{model_name}: Found")


# ============================================================
# 3. LOAD CLASS INFORMATION
# ============================================================

print("\nLoading test dataset information...")

class_names = sorted(
    [folder.name for folder in TEST_DIR.iterdir() if folder.is_dir()]
)

if len(class_names) != 2:
    raise ValueError(
        f"Expected two classes, but found: {class_names}"
    )

print("\nClass mapping:")

for index, name in enumerate(class_names):
    print(f"{index} = {name}")

# Treat abnormal as the positive class.
abnormal_matches = [
    i for i, name in enumerate(class_names)
    if "abnormal" in name.lower()
]

POSITIVE_CLASS = abnormal_matches[0] if abnormal_matches else 1
NEGATIVE_CLASS = 1 - POSITIVE_CLASS

print("\nPositive class:", class_names[POSITIVE_CLASS])
print("Negative class:", class_names[NEGATIVE_CLASS])


# ============================================================
# 4. METRIC CALCULATION FUNCTION
# ============================================================

def calculate_metrics(true_labels, predictions, probabilities):

    binary_true = (
        true_labels == POSITIVE_CLASS
    ).astype(int)

    binary_predictions = (
        predictions == POSITIVE_CLASS
    ).astype(int)

    accuracy = accuracy_score(
        true_labels,
        predictions
    )

    precision = precision_score(
        binary_true,
        binary_predictions,
        zero_division=0
    )

    recall = recall_score(
        binary_true,
        binary_predictions,
        zero_division=0
    )

    f1 = f1_score(
        binary_true,
        binary_predictions,
        zero_division=0
    )

    cm = confusion_matrix(
        true_labels,
        predictions,
        labels=[NEGATIVE_CLASS, POSITIVE_CLASS]
    )

    tn, fp, fn, tp = cm.ravel()

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else 0
    )

    auc = roc_auc_score(
        binary_true,
        probabilities
    )

    return {
        "Accuracy": accuracy,
        "Precision": precision,
        "Recall": recall,
        "Specificity": specificity,
        "F1 Score": f1,
        "AUC": auc,
        "TN": tn,
        "FP": fp,
        "FN": fn,
        "TP": tp
    }


# ============================================================
# 5. LOAD AND EVALUATE ALL THREE MODELS
# ============================================================

models = {}
all_metrics = {}
all_predictions = {}
all_probabilities = {}
true_labels = None

print("\n" + "=" * 70)
print("LOADING AND EVALUATING MODELS")
print("=" * 70)

for model_name, model_path in MODEL_FILES.items():

    print("\n" + "-" * 60)
    print(f"EVALUATING {model_name}")
    print("-" * 60)

    # Load model
    print(f"\nLoading {model_name}...")

    model = tf.keras.models.load_model(
        model_path,
        compile=False
    )

    models[model_name] = model

    print(f"{model_name} loaded successfully.")

    # Read model input dimensions where available.
    input_shape = model.input_shape

    if isinstance(input_shape, list):
        input_shape = input_shape[0]

    if len(input_shape) != 4:
        raise ValueError(
            f"Unexpected input shape for {model_name}: {input_shape}"
        )

    height = input_shape[1] or 224
    width = input_shape[2] or 224

    print(f"Model input size: {height} x {width}")

    # Load test data at the model's expected image size.
    test_ds = tf.keras.utils.image_dataset_from_directory(
        TEST_DIR,
        image_size=(height, width),
        batch_size=BATCH_SIZE,
        label_mode="binary",
        shuffle=False,
        class_names=class_names
    )

    # Get actual labels once.
    if true_labels is None:

        true_labels = np.concatenate([
            labels.numpy().flatten()
            for _, labels in test_ds
        ]).astype(int)

    # Generate predictions.
    print(f"\nGenerating {model_name} predictions...")

    raw_predictions = model.predict(
        test_ds,
        verbose=1
    )

    # Handle sigmoid or two-class softmax output.
    if raw_predictions.ndim == 2 and raw_predictions.shape[1] == 2:

        probabilities = raw_predictions[:, POSITIVE_CLASS]

        predictions = np.argmax(
            raw_predictions,
            axis=1
        )

    elif raw_predictions.ndim == 2 and raw_predictions.shape[1] == 1:

        class1_probabilities = raw_predictions.flatten()

        if POSITIVE_CLASS == 1:
            probabilities = class1_probabilities
        else:
            probabilities = 1 - class1_probabilities

        predictions = (
            class1_probabilities >= 0.5
        ).astype(int)

    else:
        raise ValueError(
            f"Unsupported output shape from {model_name}: "
            f"{raw_predictions.shape}"
        )

    # Calculate metrics.
    metrics = calculate_metrics(
        true_labels,
        predictions,
        probabilities
    )

    all_metrics[model_name] = metrics
    all_predictions[model_name] = predictions
    all_probabilities[model_name] = probabilities

    print(f"\n{model_name} Results:")

    for metric, value in metrics.items():
        print(f"{metric:<15}: {value:.4f}" if isinstance(value, float)
              else f"{metric:<15}: {value}")


# ============================================================
# 6. MODEL COMPARISON TABLE
# ============================================================

print("\n" + "=" * 70)
print("FINAL MODEL PERFORMANCE COMPARISON")
print("=" * 70)

metrics_to_display = [
    "Accuracy",
    "Precision",
    "Recall",
    "Specificity",
    "F1 Score",
    "AUC"
]

comparison = pd.DataFrame({
    "Metric": metrics_to_display,

    "VGG16": [
        all_metrics["VGG16"][m]
        for m in metrics_to_display
    ],

    "MobileNetV2": [
        all_metrics["MobileNetV2"][m]
        for m in metrics_to_display
    ],

    "EfficientNetB3": [
        all_metrics["EfficientNetB3"][m]
        for m in metrics_to_display
    ]
})

print("\n", comparison.to_string(index=False))

# Save comparison CSV.
comparison_path = OUTPUT_DIR / "model_comparison.csv"

comparison.to_csv(
    comparison_path,
    index=False
)

print("\nComparison saved:", comparison_path)


# ============================================================
# 7. SAVE CLASSIFICATION REPORTS
# ============================================================

print("\nGenerating classification reports...")

for model_name in MODEL_FILES:

    report = classification_report(
        true_labels,
        all_predictions[model_name],
        labels=[0, 1],
        target_names=class_names,
        zero_division=0
    )

    report_path = OUTPUT_DIR / (
        f"{model_name.lower()}_classification_report.txt"
    )

    with open(report_path, "w", encoding="utf-8") as file:
        file.write(report)

    print(f"Saved: {report_path}")


# ============================================================
# 8. CONFUSION MATRIX FUNCTION
# ============================================================

def save_confusion_matrix(
    true_labels,
    predictions,
    model_name
):

    cm = confusion_matrix(
        true_labels,
        predictions,
        labels=[0, 1]
    )

    plt.figure(figsize=(7, 6))

    plt.imshow(
        cm,
        interpolation="nearest"
    )

    plt.title(f"{model_name} - Confusion Matrix")
    plt.colorbar()

    tick_marks = np.arange(len(class_names))

    plt.xticks(
        tick_marks,
        class_names
    )

    plt.yticks(
        tick_marks,
        class_names
    )

    plt.xlabel("Predicted Label")
    plt.ylabel("True Label")

    threshold = cm.max() / 2 if cm.max() > 0 else 0

    for i in range(cm.shape[0]):

        for j in range(cm.shape[1]):

            plt.text(
                j,
                i,
                str(cm[i, j]),
                horizontalalignment="center",
                verticalalignment="center",
                color="white" if cm[i, j] > threshold else "black",
                fontsize=14
            )

    plt.tight_layout()

    filename = (
        f"{model_name.lower()}_confusion_matrix.png"
    )

    save_path = OUTPUT_DIR / filename

    plt.savefig(
        save_path,
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()

    print("Saved:", save_path)


# ============================================================
# 9. GENERATE THREE CONFUSION MATRICES
# ============================================================

print("\n" + "=" * 70)
print("GENERATING CONFUSION MATRICES")
print("=" * 70)

for model_name in MODEL_FILES:

    save_confusion_matrix(
        true_labels,
        all_predictions[model_name],
        model_name
    )


# ============================================================
# 10. ROC CURVE COMPARISON
# ============================================================

print("\nGenerating ROC curve comparison...")

binary_true = (
    true_labels == POSITIVE_CLASS
).astype(int)

plt.figure(figsize=(9, 7))

for model_name in MODEL_FILES:

    fpr, tpr, _ = roc_curve(
        binary_true,
        all_probabilities[model_name]
    )

    auc_value = all_metrics[model_name]["AUC"]

    plt.plot(
        fpr,
        tpr,
        label=f"{model_name} (AUC = {auc_value:.4f})"
    )

plt.plot(
    [0, 1],
    [0, 1],
    linestyle="--",
    label="Random Classifier"
)

plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")

plt.title("ROC Curve - DFU Detection Models")

plt.legend(loc="lower right")
plt.grid(True, alpha=0.3)

plt.tight_layout()

roc_path = OUTPUT_DIR / "roc_curve_comparison.png"

plt.savefig(
    roc_path,
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("ROC curve saved:", roc_path)


# ============================================================
# 11. THREE MODEL PERFORMANCE COMPARISON GRAPH
# ============================================================

print("\nGenerating three-model comparison graph...")

x = np.arange(len(metrics_to_display))
width = 0.25

plt.figure(figsize=(13, 7))

model_names = [
    "VGG16",
    "MobileNetV2",
    "EfficientNetB3"
]

for i, model_name in enumerate(model_names):

    values = [
        all_metrics[model_name][metric]
        for metric in metrics_to_display
    ]

    plt.bar(
        x + (i - 1) * width,
        values,
        width,
        label=model_name
    )

plt.xticks(
    x,
    metrics_to_display,
    rotation=15
)

plt.ylabel("Score")
plt.ylim(0, 1.05)

plt.title(
    "Performance Comparison of VGG16, MobileNetV2 and EfficientNetB3"
)

plt.legend()
plt.grid(axis="y", alpha=0.3)

plt.tight_layout()

chart_path = OUTPUT_DIR / "model_comparison_chart.png"

plt.savefig(
    chart_path,
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Comparison graph saved:", chart_path)


# ============================================================
# 12. FINAL EVALUATION SUMMARY
# ============================================================

print("\n" + "=" * 70)
print("EVALUATION COMPLETED SUCCESSFULLY")
print("=" * 70)

print("\nModels evaluated:")

for model_name in MODEL_FILES:
    print(f" - {model_name}")

print("\nGenerated files:")

for file in sorted(OUTPUT_DIR.iterdir()):

    if file.is_file():
        print(" -", file.name)

print("\nAll three models have been evaluated.")
print("Results are saved in the evaluation folder.")

print("=" * 70)
